﻿using Xunit;
using Moq;
using netcore_App.Models;
using netcore_App.Controllers;
using System.Collections.Generic;

namespace netcore_App.Tests
{
    public class ProductControllerTests
    {
        [Fact]
        public void Can_Paginate()
        {
            Mock<IProductRepository> mock = new Mock<IProductRepository>();
            mock.Setup(m => m.Products).Returns(new Product[]
                {
                new Product{ProductID=1,Name="W1"},
                new Product{ProductID=2,Name="W2"},
                new Product{ProductID=1,Name="W3"},
                new Product{ProductID=1,Name="W4"},
                new Product{ProductID=1,Name="W5"}
                });
            ProductController controller = new ProductController(mock.Object);
            controller.PageSize = 3;

            IEnumerable<Product> result = controller.List(2).ViewData.Model;
        }

    }
}
