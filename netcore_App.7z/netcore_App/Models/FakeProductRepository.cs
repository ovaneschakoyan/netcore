﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace netcore_App.Models
{
    public class FakeProductRepository /*:IProductRepository*/
    {
        public IEnumerable<Product> Products => new List<Product>
        {
            new Product{Name="Trianon",Price=135},
            new Product{Name="Petit Verdon",Price=200}
        };
    }
}
