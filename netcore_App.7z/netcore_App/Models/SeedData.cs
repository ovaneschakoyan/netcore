﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace netcore_App.Models
{
    public static class SeedData
    {
        public static void EnsurePopulated(IApplicationBuilder app)
        {
            ApplicationDbContext context = app.ApplicationServices.GetRequiredService<ApplicationDbContext>();
            if(!context.Products.Any())
            {
                context.Products.AddRange(
                    new Product
                    {
                        Name = "2014 Adagio",

                        LongDescription = "Best described as an elegant wine with a strong sense of identity.  There are some wonderful essences of blueberry, strawberry, raspberry, cranberry and cherry.  With these bright fruits are some darker aged fruits such as date and figs.  Along with this there is a soft forest floor note that brings in a great earthy character to the wine which is balanced well with some notes of vanilla and violet’s lending a floral quality.  The tannins are string yet still smooth and approachable. The oak is wonderfully incorporated into the wine.  All of these aspects lend themselves to creating an elegant wine.",
                        Category = "Reds",
                        Price = 240.00M
                    },
                    new Product
                    {
                        Name = "2014 Trianon",
                        Description = "The first impression is a lighter style wine but don’t let that deceive you.  This wine has tremendous character with a fruit forward quality.  There are fresh berry notes mixed in with the aged darker fruits.  After the fruit is a fresh sugar snap pea and herbaceous tone with a touch of menthol.  It then goes into a sweet tobacco leaf and leather with a touch of fresh mushroom.  The wine finishes very clean with soft tannins and well integrated oak.  There is a touch of brightness on the finish that creates a pleasant lingering affect with the fresh fruit.",
                        Category = "Reds",
                        Price = 300
                    },
                    new Product
                    {
                        Name = "2014 Gabriel Archer Reserve",
                        Description = "A lovely dark cranberry colored wine with a fruit forward nose offering all the various fruit families – berries, stone fruits and tree fruits.  Some of the fruits have a chocolate coating.  This is all backed up with some soft floral/herbal notes with a touch of lemon grass.  There are some aged fruits as well thrown into the mix.  A wonderfully elegant wine with many layers and great balance.  The tannins and oak are well integrated into the wine and the finish is soft, long and lingering.  I believe this vintage Gabriel Archer may prove to be one for the ages. ",
                        Category = "Reds",
                        Price = 265
                    },
                    new Product
                    {
                        Name = "2014 Limited Release Cabernet Franc",
                        Description = "The first impression is a lighter style wine but don’t let that deceive you.  This wine has tremendous character with a fruit forward quality.  There are fresh berry notes mixed in with the aged darker fruits.  After the fruit is a fresh sugar snap pea and herbaceous tone with a touch of menthol.  It then goes into a sweet tobacco leaf and leather with a touch of fresh mushroom.  The wine finishes very clean with soft tannins and well integrated oak.  There is a touch of brightness on the finish that creates a pleasant lingering affect with the fresh fruit.The Cabernet Franc has a wonderful balance of the earthy tones of truffles, mushrooms, and tea along with the fresh red fruit and dried fruit.  Additionally there is a pleasant touch of nutmeg, clove and spice that enhances the fruit characters.  The mouthfeel of the wine is well balanced with a nice mid-palate structure and a soft lingering affect of fresh fruit .  The tannins and oak are nicely integrated into the wine complementing the other nuances.  A very food friendly wine with many layers to explore.",
                        Category = "Reds",
                        Price = 350
                    },
                    new Product
                    {
                        Name = "2015 Limited Release Mount Juliet Red",
                        Description = "This is the first Mt Juliet Red we have made and I am happy with how the vintage is reflected in the bottle and the overall balance of the wine. The fruit aspect is comprised of a mixed bag of berries along with some currants and hint of dark fruits. There is a nice layer of spice that goes well with the fruit and cocoa/vanilla touches. There is additionally a hint of an earthy character showing some olives and mushrooms. The oak is nicely layered with the fruit and the tannins are bold but yet soft and approachable. The finish has a bright aspect that will lend itself nicely to pairing with many different foods.",
                        Category = "Reds",
                        Price = 180
                    },
                    new Product
                    {
                        Name = "2015 Petit Verdot",
                        Description = "This new release is a delicious addition to the Williamsburg Winery family.  The nose is very complex with upfront blackberry, blueberry, black currant, pomegranate, and black cherry aromas followed by notes of black pepper, toast, and vanilla.  This is balanced by some dried fruit, notably medjool dates and figs.  On the palate, there is a flash of chocolate covered berry.  The finish is very long and clean with lingering tannins in balance with a hint of spice.  Overall this is a very complex Petit Verdot with many layers of aroma and flavor.",
                        Category = "Reds",
                        Price = 400
                    },
                    new Product
                    {
                        Name = "2015 Barrel Aged Virginia Claret",
                        Description = "Initially the wine shows a blend of blackberry, blueberry, raspberry, strawberry and dark cherry.  Then there are some lovely herbal notes with tea, fennel and olives with nuances of cocoa and vanilla.  There is additionally a nice earthiness with some suede/leather and a bit of limestone to give it a mineral character.  The tannins are smooth and approachable and the oak is well integrated with the fruit.  The finish is long and bright with the berries showing well.",
                        Category = "Reds",
                        Price = 245
                    },
                    new Product
                    {
                        Name = "2014 Arundell Cabernet Sauvignon",
                        Description = "This new release is a delicious addition to the Williamsburg Winery family.  The nose is very complex with upfront blackberry, blueberry, black currant, pomegranate, and black cherry aromas followed by notes of black pepper, toast, and vanilla.  This is balanced by some dried fruit, notably medjool dates and figs.  On the palate, there is a flash of chocolate covered berry.  The finish is very long and clean with lingering tannins in balance with a hint of spice.  Overall this is a very complex Petit Verdot with many layers of aroma and flavor.",
                        Category = "Reds",
                        Price = 280
                    },
                    new Product
                    {
                        Name = "2014 Susan Constant Red",
                        Description = "There is a nice mix of red and dark fruits showing strawberry, currant and cherry along with the figs and dates.  In addition to the fruit there is a gentle earthiness of tobacco, wild mushroom, suede and olive along with a touch of the forest floor.  The creamy vanilla character follows well and leads into some sweet tannins.  Without the oak you can perceive the layers of the syrah making it easy to drink yet with a mature finish.  A fantastic bargain wine.",
                        Category = "Reds",
                        Price = 175
                    },
                    new Product
                    {
                        Name = "2015 Vintage Reserve Chardonnay",
                        Description = "It has been awhile since the last Vintage Reserve Chardonnay and I am happy to report the wait was worth it.  The 2015 is showing some wonderful upfront tropical characters of pineapple, orange and banana with some apricot and plum to round out the fruits.  There is a very clean creamy lemon note with some vanilla.  The minerality of the wine is nicely balanced with the fruits.  The oak is not overstated and blends nicely with the fruit and minerality of the wine.  The finish is luscious with many layers and complexities.",
                        Category = "Whites",
                        Price = 320
                    },
                     new Product
                     {
                         Name = "2015 A Midsummer Night's White",
                         Description = "This fruity, slightly sweet and highly aromatic wine was produced from an extremely low-yield vineyard on Wessex Hundred, the farm upon which The Williamsburg Winery is located.",
                         Category = "Whites",
                         Price = 410
                     },
                     new Product
                     {
                         Name = "2016 Viognier – New Release!",
                         Description = "Estate grown Viognier from the Williamsburg Winery Vineyards.This wine could be described as Pineapple - upside - down - cake,with hints of  banana,orange,apple and lemon - grass.This is a very rich,smooth sensual wine with a touch of spiciness in its personality.This wine will be best served during a romantic meal.",
                         Category = "Whites",
                         Price = 350
                     },
                    new Product
                    {
                        Name = "2015 Petite Fleur",
                        Description = "Visually this wine is a wonderful soft amber gold color.  The Aromas start with orange, tangerine, pineapple and pear.  The fruit is followed by a lovely honeysuckle note that plays well with the perfumed flowers.",
                        Category = "Desserts and Specially Wines",
                        Price = 515
                    },
                     new Product
                     {
                         Name = "Vin Licoreux de Framboise - Wine with Raspberry",
                         Description = "This dessert wine showcases the brightness of raspberries with the subtle nuances of Merlot. Serve lightly chilled after dinner or with chocolate or fruit-based desserts.",
                         Category = "Desserts and Specially Wines",
                         Price = 490
                     },
                     new Product
                     {
                         Name = "Jamestown Cellars Settlers' Spiced Wine",
                         Description = "Colonial tradition of cloves, cinnamon, nutmeg, and other spices were added to this Merlot-Cabernet Sauvignon blend. Designed as a mulled wine, it is meant to be served warm during winter by the fireplace or after a cold day outdoors.  When served chilled in the summer months, it makes an agreeable substitute to Sangria. In the cold Winters of northern Europe, wine would often be served warm during the holiday season. The English brought this custom to Virginia in the 16th century.",
                         Category = "Desserts and Specially Wines",
                         Price = 500
                     });
                context.SaveChanges();
            }
        }
    }
}
