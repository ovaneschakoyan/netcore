# WineryStore_netcore
.netcore_app
